import React from 'react'
import { createRoot } from 'react-dom/client'
import { Phone, MessageCircle, ClipboardList, ShieldCheck, MapPin, Mail, CheckCircle, Truck, Star, Camera } from 'lucide-react'
import logo from './assets/sj-logo.jpg'
import './styles.css'

const phone = '9126103310'
const displayPhone = '(912) 610-3310'
const email = 'snjstripingllc@gmail.com'

function App() {
  const services = [
    ['Parking Lot Restriping', 'Refresh faded parking spaces with crisp, clean lines.'],
    ['ADA Handicap Markings', 'Accessible parking symbols, access aisles, and compliant markings.'],
    ['Fire Lane Striping', 'Bright fire lane and no-parking markings for safety and visibility.'],
    ['Directional Arrows', 'Traffic flow arrows, stop bars, and pavement messages.'],
    ['Curb Painting & Stenciling', 'Professional curb paint and custom stencil markings.'],
    ['New Layout Striping', 'Layout support for new or redesigned parking areas.']
  ]

  return (
    <div className="site">
      <header className="header">
        <a className="brand" href="#home"><img src={logo} alt="S&J Striping LLC logo" /></a>
        <nav><a href="#services">Services</a><a href="#about">About</a><a href="#estimate">Estimate</a><a href="#contact">Contact</a></nav>
        <a className="header-call" href={`tel:${phone}`}><Phone size={18} /> {displayPhone}</a>
      </header>

      <main>
        <section id="home" className="hero">
          <div className="hero-content">
            <p className="eyebrow">Locally Owned • Reliable • Professional</p>
            <h1>Professional Parking Lot Striping & Pavement Marking</h1>
            <p className="hero-subtitle">Clean, durable striping for commercial properties, apartment communities, retail centers, churches, schools, warehouses, and businesses across Southeast Georgia and the Lowcountry.</p>
            <div className="hero-actions">
              <a className="btn primary" href={`tel:${phone}`}><Phone size={20} /> Call Now</a>
              <a className="btn dark" href={`sms:${phone}`}><MessageCircle size={20} /> Text for Estimate</a>
              <a className="btn outline" href="#estimate"><ClipboardList size={20} /> Request Free Estimate</a>
            </div>
          </div>
          <div className="feature-bar">
            <div><ShieldCheck /><strong>Improve Safety</strong><span>Clear markings help guide traffic and reduce confusion.</span></div>
            <div><Star /><strong>Boost Curb Appeal</strong><span>Fresh lines make your property look maintained.</span></div>
            <div><CheckCircle /><strong>Durable Results</strong><span>Professional materials and careful application.</span></div>
            <div><Truck /><strong>Regional Service</strong><span>Based in Effingham County, serving a 3–4 hour radius.</span></div>
          </div>
        </section>

        <section id="services" className="section">
          <div className="section-head"><p className="eyebrow">Our Services</p><h2>Parking Lot Striping Services</h2><p>From simple restripes to new layouts, S&J Striping LLC helps keep your property safe, organized, and professional.</p></div>
          <div className="cards">{services.map(([title, text]) => <article className="card" key={title}><div className="card-icon"></div><h3>{title}</h3><p>{text}</p></article>)}</div>
        </section>

        <section id="about" className="split">
          <div><p className="eyebrow">About S&J Striping LLC</p><h2>Serving Effingham County and beyond</h2><p>S&J Striping LLC is based out of Effingham County, Georgia and serves commercial customers within a 3–4 hour driving radius, including Southeast Georgia and nearby Lowcountry areas.</p><ul className="check-list"><li><CheckCircle /> Free estimates</li><li><CheckCircle /> Commercial and local small-business friendly</li><li><CheckCircle /> Reliable communication</li><li><CheckCircle /> Professional appearance from first call to final line</li></ul></div>
          <div className="service-area"><h3>Service Area</h3><p>Effingham County • Savannah • Pooler • Statesboro • Hinesville • Brunswick • Augusta • Macon • Jacksonville • Charleston and surrounding areas</p></div>
        </section>

        <section className="section gallery"><div className="section-head"><p className="eyebrow">Project Gallery</p><h2>Photos Coming Soon</h2><p>As new jobs are completed, this section will showcase before-and-after photos of real S&J Striping LLC projects.</p></div><div className="photo-placeholder"><Camera size={48} /><p>Ready for your future parking lot project photos.</p></div></section>

        <section id="estimate" className="estimate"><div className="estimate-card"><div className="section-head"><p className="eyebrow">Free Estimate</p><h2>Request a Free Estimate</h2><p>Send the job details below, or call/text Shawn directly at {displayPhone}.</p></div><form action={`mailto:${email}`} method="post" encType="text/plain"><input name="Name" placeholder="Full Name" required /><input name="Phone" placeholder="Phone Number" required /><input name="Email" type="email" placeholder="Email Address" /><input name="Property Location" placeholder="Property Address / Location" /><input name="Approximate Spaces" placeholder="Approx. Number of Parking Spaces" /><textarea name="Job Details" placeholder="Tell us about the job..." rows="6"></textarea><button className="btn primary form-btn" type="submit">Submit Estimate Request</button></form></div></section>

        <section id="contact" className="contact"><div><p className="eyebrow">Contact</p><h2>Get in touch with S&J Striping LLC</h2><p>Need fresh lines, safer traffic flow, or a professional-looking lot? Call, text, or email today.</p></div><div className="contact-box"><a href={`tel:${phone}`}><Phone /> {displayPhone}</a><a href={`sms:${phone}`}><MessageCircle /> Text for a Free Estimate</a><a href={`mailto:${email}`}><Mail /> {email}</a><span><MapPin /> Effingham County, GA</span></div></section>
      </main>

      <footer><strong>S&J Striping LLC</strong><span>Professional parking lot striping and pavement marking across Southeast Georgia.</span></footer>
    </div>
  )
}

createRoot(document.getElementById('root')).render(<App />)
