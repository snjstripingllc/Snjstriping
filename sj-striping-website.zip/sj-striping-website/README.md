# S&J Striping LLC Website

## Upload to GitHub
1. Create a new repository named `sj-striping-website`.
2. Upload everything inside this folder.
3. In Vercel, click Add New Project.
4. Import the GitHub repository.
5. Click Deploy.

## Connect the domain
In Vercel, go to Project Settings > Domains and add `snjstriping.com`.
Vercel will show the DNS records to add in Namecheap.
